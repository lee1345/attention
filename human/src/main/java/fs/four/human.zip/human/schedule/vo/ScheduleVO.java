package fs.four.human.schedule.vo;

public class ScheduleVO {
    private String t_title;
    private String t_stage;
    private String t_priority;
    private String t_content;
    private String t_start_date;
    private String t_start_time;
    private String t_end_date;
    private String t_end_time;
    private String t_group;

    public String getT_title() {
        return t_title;
    }

    public void setT_title(String t_title) {
        this.t_title = t_title;
    }

    public String getT_stage() {
        return t_stage;
    }

    public void setT_stage(String t_stage) {
        this.t_stage = t_stage;
    }

    public String getT_priority() {
        return t_priority;
    }

    public void setT_priority(String t_priority) {
        this.t_priority = t_priority;
    }

    public String getT_content() {
        return t_content;
    }

    public void setT_content(String t_content) {
        this.t_content = t_content;
    }

    public String getT_start_date() {
        return t_start_date;
    }

    public void setT_start_date(String t_start_date) {
        this.t_start_date = t_start_date;
    }

    public String getT_start_time() {
        return t_start_time;
    }

    public void setT_start_time(String t_start_time) {
        this.t_start_time = t_start_time;
    }

    public String getT_end_date() {
        return t_end_date;
    }

    public void setT_end_date(String t_end_date) {
        this.t_end_date = t_end_date;
    }

    public String getT_end_time() {
        return t_end_time;
    }

    public void setT_end_time(String t_end_time) {
        this.t_end_time = t_end_time;
    }

    public String getT_group() {
        return t_group;
    }

    public void setT_group(String t_group) {
        this.t_group = t_group;
    }
}
