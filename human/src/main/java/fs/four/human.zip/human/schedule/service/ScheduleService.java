package fs.four.human.schedule.service;

import fs.four.human.schedule.vo.ScheduleVO;

import java.util.List;

public interface ScheduleService {
    List<ScheduleVO> getSchedules();
}
