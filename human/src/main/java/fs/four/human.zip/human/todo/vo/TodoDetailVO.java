package fs.four.human.todo.vo;

import lombok.Data;

@Data
public class TodoDetailVO {
    Long td_id;
    String td_participant_1;
    String td_participant_2;
    String td_participant_3;
    String td_participant_4;
    String td_participant_5;
}
