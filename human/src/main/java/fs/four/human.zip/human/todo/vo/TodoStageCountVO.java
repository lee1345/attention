package fs.four.human.todo.vo;

import lombok.Data;

import java.util.Date;

@Data
public class TodoStageCountVO {
    private String t_stage;
    private String count;

}
