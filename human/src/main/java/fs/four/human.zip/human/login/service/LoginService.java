package fs.four.human.login.service;

import fs.four.human.login.vo.LoginVO;

public interface LoginService {
    void signUp(LoginVO loginVO);
}
